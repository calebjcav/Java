package main;
/*

import sample.Classes.Model.InHousePart;

public class Controller {
        addPartPagesave.setOnAction(e -> {
        if (tableValidator() == true)

            InHousePart newpart = new InHousePart(getFormattedTableData());
        return
    }
            else{

    }
});

}

 */